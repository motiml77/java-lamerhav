package examples;

import unit4.collectionsLib.*;
import java.util.Arrays;

/** דוגמאות מערכים: מקום המקסימום, היפוך במקום, סכומי שורות במערך דו-ממדי, מיון בועות */
public class ArrayExamples {

    /** האינדקס של האיבר הגדול ביותר */
    public static int maxIndex(int[] arr) {
        int max = 0;                      // האינדקס של הגדול שמצאנו עד עכשיו
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > arr[max]) max = i;
        }
        return max;
    }

    /** היפוך המערך במקום — שני אינדקסים שמתקרבים זה לזה */
    public static void reverse(int[] arr) {
        int left = 0, right = arr.length - 1;   // שני אינדקסים: אחד מההתחלה ואחד מהסוף
        while (left < right) {
            int tmp = arr[left];                // tmp שומר ערך כדי לא לאבד אותו בהחלפה
            arr[left] = arr[right];
            arr[right] = tmp;
            left++;
            right--;
        }
    }

    /** מערך עם הסכום של כל שורה */
    public static int[] rowSums(int[][] mat) {
        int[] sums = new int[mat.length];   // sums[r] = הסכום של שורה r
        for (int r = 0; r < mat.length; r++) {
            for (int c = 0; c < mat[r].length; c++) {
                sums[r] += mat[r][c];
            }
        }
        return sums;
    }

    /** מיון בועות */
    public static void bubbleSort(int[] a) {
        for (int i = 0; i < a.length - 1; i++) {
            for (int j = 0; j < a.length - 1 - i; j++) {
                if (a[j] > a[j + 1]) {
                    int tmp = a[j];             // החלפה של שני שכנים: tmp שומר את הראשון
                    a[j] = a[j + 1];
                    a[j + 1] = tmp;
                }
            }
        }
    }

    // מומלץ להריץ "שורה אחר שורה" — רואים את i, j, left, right זזים על המערך
    public static void main(String[] args) {
        int[] arr = {7, 3, 9, 1, 5};
        System.out.println("המקסימום במקום " + maxIndex(arr));
        reverse(arr);
        bubbleSort(arr);

        int[][] mat = {
            {1, 2, 3},
            {4, 5, 6}
        };
        System.out.println("סכומי שורות: " + Arrays.toString(rowSums(mat)));
    }
}
